                     //Chapter 17-20.
//  1. Declare and initialize an empty multidimensional array.
//  (Array of arrays)

// var Arr=[[1,2],[3,4],[5,6]];

//  2. Declare and initialize a multidimensional array
//  representing the following matrix:

// var arry =[
//     [0,1,2,3],
//     [1,0,1,2],
//     [2,1,0,1],
// ]
// for (a = 0; a < arry.length; a++){
//     for(var b = 0; b < b.length; b++){
//         document.write(arry[a][b]+ " ");
//     }
//     document.write("<br>")
// }
// 3. Write a program to print numeric counting from 1 to 10.

// var array =[
//     [1],
//     [2],
//     [3],
//     [4],
//     [5],
//     [6],
//     [7],
//     [8],
//     [9],
//     [10],
// ] 
// for (a = 0; a < array.length; a++){
// document.write( array[a] +"<br>" );
// }


// 4. Write a program to print multiplication table of any
// number using for loop. Table number & length should be
// taken as an input from user.

// var table = prompt("Enter table number");
// var a = prompt( "Enter table lenght");
// for ( var i = 1; i <= a; i++){
// document.write(table + " * " + i +" " + "=" +" " + (i*table) + "<br>")
// }


// 5. Write a program to print items of the following array
// // using for loop:
// fruits = [“apple”, “banana”, “mango”, “orange”,
// “strawberry”]

// var fruits = ["Apple" , "Banana", "Mango" , "Orange" , "Strawberry"];
// for (var a =0; a < 5; a++ ){
//     document.write(fruits [a] + " " +"<br>");
//     }
//     document.write("<br>");
// for(var a = 0; a < 5; a++ ){
// document.write("Element at index" + " " + a + " " + "is" + " " + fruits[a] + "<br>" );
// }

// 6. Generate the following series in your browser. See
// example output.
// a. Counting: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

// document.write ("<h1>Counting:</h1>" );

// var counting = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
// document.write(counting);

// b. Reverse counting: 10, 9, 8, 7, 6, 5, 4, 3, 2, 1

// document.write ("<h1>Reverse Counting:</h1>" );

// var reverseCounting = [1,2,3,4,5,6,7,8,9,10];
// for (var a = 9; a >= 0; a--){
//     document.write(reverseCounting[a] + " ");
// }

// c. Even: 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20

//  document.write ("<h1>Even:</h1>" );

//  var even = [2,4,6,8,10,12,14,16,18,20 ];
//  for(var a = 0; a < 10; a++){
//      document.write (even[a] + " ");
//  }

// for(i=2;i<=20;i+=2){
//     document.write(i)
// }

// d. Odd: 1, 3, 5, 7, 9, 11, 13, 15, 17, 19

//  
// e. Series: 2k, 4k, 6k, 8k, 10k, 12k, 14k, 16k, 18k, 20k

// document.write ("<h1>Series:</h1>" );

// var series = ["2k, 4k, 6k, 8k, 10k, 12k, 14k, 16k, 18k, 20k" ]
// document.write(series);


// 7. You have an array
// A = [“cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array.
// After searching, prompt the user whether the given item is
// found in the list or not. Example:

// var bakery = prompt ("Welcome to our Bakery Enter your oeder mame/sir");
// var A = ["cake", "apple pie", "cookie", "chips", "patties"];

// for( i = 0; i < A.length; i++){
//   if  (A[i] === bakery ){
   
// document.write ("availibale at "+i);
//   }
//   else{
// document.write("sorry mame/sir your order is not available" );
//   }
//   break
// }


// 8. Write a program to identify the largest number in the
// given array.
// A = [24, 53, 78, 91, 12].

// A = [24, 53, 78, 91, 12]
// var largest=A.sort();
// for (var i=0; i<4;i++){
//     if (A[i]>largest) {
//         var A=largest[i];   
//     }
// }
// document.write("A is" + A + "<br>" + "The largest number is" + " " + largest[i]);



// 9. Write a program to identify the smallest number in the
// given array.
// A = [24, 53, 78, 91, 12]

// var A = [24, 53, 78, 91, 12]

// A.sort()

// document.write(A[0])


// 10. Write a program to print multiples of 5 ranging 1 to
// 100.

// var a = 5;
// for (var i = 1; i <= 20; i++){
//     document.write(a * i +" ")
// }


                                       // Chapter 21-25

//   1. Write a program that takes two user inputs for first and
//   last name using prompt and merge them in a new variable
//   titled fullName. Greet the user using his full name.


// var firstName = prompt("Enter your first name ");
// var lastName = prompt("Enter your last name");
// var fullName = firstName + " " + lastName;
// document.write("Thanks to use your full name" + " " + fullName);


// 2. Write a program to take a user input about his favorite
// mobile phone model. Find and display the length of user
// input in your browser

// var input = prompt ("Enter your favorite mobile phone model");
// var str = input.length;
// document.write("My favorite mobile is" + " " + input + "<br>" + "Lenght of string" + " " + str );


// 3. Write a program to find the index of letter “n” in the word
// // “Pakistani” and display the result in your browser .
// var city = "Pakistani";
// var index =city.indexOf("n");
// document.write ("String:" + city + "<br>" + "<br>" +"index of n is "+ " "+ index);


// 4. Write a program to find the last index of letter “l” in the
// word “Hello World” and display the result in your browser.

//  var city = "Hello World";
//  var index =city.lastIndexOf("l");
//  document.write ("String:" + city + "<br>" + "<br>" +"index of l is "+ " "+ index);


// 5. Write a program to find the character at 3rd index in the
// word “Pakistani” and display the result in your browser.

// var str = "Pakistani";
// var index = str.charAt(3);
// document.write("String:" + " " + str + "<br>" + "Character of 3rd index is:" + " " + index );


// 6. Repeat Q1 using string concat() method.

// var firstName = prompt("Enter your first name ");
// var lastName = prompt("Enter your last name");
// var fullName = firstName.concat( " " + lastName);
// document.write("Thanks to use your full name" + " " + fullName);


// 7. Write a program to replace the “Hyder” to “Islam” in the
// word “Hyderabad” and display the result in your browser.

// var city = "Hyderabad";
// var c = city.replace("Hyder", "Islam")
// document.write(city + " <br>" + "After Replacment" + " " +c);


// 8. Write a program to replace all occurrences of “and” in the
// string with “&” and display the result in your browser.
// var message = “Ali and Sami are best friends. They play cricket and
// football together.”;

// var text = "“Ali and Sami are best friends. They play cricket and football together."
// var replace = text.replace(/and/g,"&");
// document.write(text + "<br>" +"<br>" + replace);


// 9. Write a program that converts a string “472” to a number
// 472. Display the values & types in your browser.

// var str = "472";
// var num = Number(str);
// document.write("Value:" + " " + str + "<br>" + "Type String" + "<br>" + "<br>" + "Value:" + " " + num + "<br>" + "Type Number" );

// 10. Write a program that takes user input. Convert and
// show the input in capital letters.

// var str = prompt ("Enter some thing");
// var a = str.toUpperCase();
// document.write(a);


// 11. Write a program that takes user input. Convert and
// show the input in title case.

// var str = prompt ("Enter some thing");
// var a = str[0].toUpperCase()
// var b=str.slice(1).toLowerCase()
// document.write("Usear input" + " " + str + "<br> "+ "Lowercase"+ " " +a+b);

// var a =prompt("enter")
// var b=a.split()
// for(i=0;i<b.length;i++){
//    var c=b[i]
//    var d=c[1]
//    console.log(d)
// }

// var arry=["abc","adv","asf"]
// console.log(arry[0])

// 12. Write a program that converts the variable num to
// string.
// var num = 35.36 ;
// Remove the dot to display “3536” display in your browser.

//  var num = 35.36;
//  var result = parseInt(num);
//  document.write("Number" + " " + num + "<br>" + "<br>" + "Result" + " " + result );

// 13. Write a program to take user input and store username
// in a variable. If the username contains any special symbol
// among [@ . , !], prompt the user to enter a valid username.
// For character codes of [@ .
// Note:
// ASCII code of ! is 33
// ASCII code of , is 44
// ASCII code of . is 46
// ASCII code of @ is 64

// var a=prompt("enter user name")
// var b=a
// for(i=0;i<a.length;i++){
//   if(b[i]==="@",b[i]==="!",b[i]==="!",b[i]==="."){
//     alert("correct")
//   }else{
//     alert("wrong")
//   }
// }




// 14. You have an array
// A = [cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array. After searching, prompt the user whether the given
// item is found in the list or not.
// Note: Perform case insensitive search. Whether the user
// enters cookie, Cookie, COOKIE or coOkIE, program
// should inform about its availability.

// var bakery = prompt("Enter your order mame/sir");
// var array = ["cake", "apple pie", "cookie", "chips", "patties"];
// var a = bakery.search(array);
//  bakery.toLowerCase();{
// if(bakery === a){
//     document.write("your order is " + " " + bakery  + " " + "available");
// }
// else(bakery !== a);{
// document.write("Oops sorry your order is not available");
// }
//  }


// 16. Write a program to convert the following string to an
// array using string split method.
// var university = “University of Karachi”;
// Display the elements of array in your browser.

// var university = "University of Karachi";
// var a = university.split("");
// for (var i=0; i<a.length; i++){
// document.write(a[i] + "<br>")
// }


// 17. Write a program to display the last character of a user
// input.

// var input = prompt("Enter some thing");
// document.write(input + " " + "<br>" + "last character is" + " " +  input.slice(-1) );


// 18. You have a string “The quick brown fox jumps over the
// lazy dog”. Write a program to count number of
// occurrences of word “the” in given string.

// var txt = "“the quick brown fox jumps over the lazy dog”.";
// var count = (txt.match(/the/g) || []).length;
// document.write("Text:" + " " + txt + "<br>" + "There are " + " " + count  + " " + "occurrences of word “the”" );










